#include<stdio.h>
int main(){
    int n1 , n2 , n3 , n4 , smallest;
    printf("Enter number:");scanf("%d" , &n1);
    printf("Enter number:");scanf("%d" , &n2);
    printf("Enter number:");scanf("%d" , &n3);
    printf("Enter number:");scanf("%d" , &n4);

    smallest = n1;
    if(n2 < smallest){
        smallest = n2;
    }
    if(n3 < smallest){
        smallest = n3;
    }
    if(n4 < smallest){
        smallest = n4;
    }
    printf("Among these 4 input numbers(%d, %d, %d, and %d) , the smallest is %d" , n1 , n2 , n3 , n4 , smallest);

    return 0;
}
