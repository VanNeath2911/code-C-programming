#include <stdio.h>
#include <string.h>
int main() {
    char player1[10], player2[10];
    printf("Enter option (rock, paper, scissor) by player 1: ");scanf("%s", player1);
    printf("Enter option (rock, paper, scissor) by player 2: ");scanf("%s", player2);
    if (strcmp(player1, player2) == 0) {
        printf("The player 1 & 2 are equal because they have the same %s.\n", player1);
    } else if ((strcmp(player1, "rock") == 0 && strcmp(player2, "scissor") == 0) ||
               (strcmp(player1, "paper") == 0 && strcmp(player2, "rock") == 0) ||
               (strcmp(player1, "scissor") == 0 && strcmp(player2, "paper") == 0)) {
        printf("The player 1 won the player 2 because %s wins %s.\n", player1, player2);
    } else {
        printf("The player 2 won the player 1 because %s wins %s.\n", player2, player1);
    }

    return 0;
}
