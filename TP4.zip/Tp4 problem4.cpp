#include<stdio.h>
#include<string.h>
int main(){
    char word[22];
    printf("Enter word:");scanf("%s" , word);

    if(word[0] == word[strlen(word)-1]){
        if(word[1] == word[strlen(word)-2]){
            printf("The word %s is a palindrome." , word);
        }
    } 
    else{
        printf("The word %s is not a palindrome." , word);
    }
    return 0;
}
