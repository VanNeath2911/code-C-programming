#include<stdio.h>
enum Operation{
	SUM='+', SUB='-', MUL= '*', DIV='/'
};
main(){	
enum Operation sign;
	while(1){
		char operation;
		float num1, num2;
		float sum, sub, mul, div;
		printf("Enter a operation(+, -, *, /): ");
		scanf(" %c", &operation);
		printf("Enter number1:");
		scanf("%f", &num1);
		printf("Enter number2:");
		scanf("%f", &num2);
	
		switch(operation){
		case SUM:
			sum = num1 + num2;
			printf("The result of summation is: %.2f \n", sum );
			break;
		case SUB:
			sub = num1 - num2;
			printf("The result of submation is: %.2f \n",  sub);	
			break;
		case MUL:
			mul =  num1 * num2;
			printf("The result of multiplication is: %.2f \n", mul);
			break;
		case DIV:
			if(num2 == 0){
				printf("The number2 must be bigger than 0 \n");
			}else{
				div = num1 / num2;
				printf("The result of division is: %.2f \n", div);	
			}
			break;
		}
	}
	
	

}
