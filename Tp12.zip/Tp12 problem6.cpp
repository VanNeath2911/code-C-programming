#include <stdio.h>
enum Shape {
    CIRCLE,
    SQUARE,
    TRIANGLE
};
float calculateCircleArea(float radius) {
    return 3.14 * radius * radius;
}
float calculateSquareArea(float side) {
    return side * side;
}

float calculateTriangleArea(float base, float height) {
    return 0.5 * base * height;
}
int main() {
    int choice;
    enum Shape selectedShape;
    printf("Choose a shape:\n");
        printf("1. Circle\n");
        printf("2. Square\n");
        printf("3. Triangle\n");
        printf("Enter your choice (1,2,3): ");scanf("%d", &choice);
    while (1) {
        switch (selectedShape) {
            case CIRCLE:
                float radius;
                printf("Enter the radius of the circle: ");scanf("%f", &radius);
                printf("Area of the circle: %.2f\n", calculateCircleArea(radius));
                break;
            case SQUARE:
                float side;
                printf("Enter the side length of the square: ");scanf("%f", &side);
                printf("Area of the square: %.2f\n", calculateSquareArea(side));
                break;
            case TRIANGLE:
                float base, height;
                printf("Enter the base and height of the triangle: ");scanf("%f %f", &base, &height);
                printf("Area of the triangle: %.2f\n", calculateTriangleArea(base, height));
                break;
            default:
                printf("Invalid choice. Please select 1, 2, or 3.\n");
        }
	}
    return 0;
}
