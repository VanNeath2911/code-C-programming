#include<stdio.h>
enum StudentGrades{
	A=1, B, C, D, F
};
main(){
	enum StudentGrades grade;
	while(1){
		printf("Enter your grade: ");
		scanf("%d", &grade);
		switch(grade){
			case A:
				printf("Excellent \n");
				break;
			case B:
				printf("Very good \n");
				break;
			case C:
				printf("Good \n");
				break;
			case D:
				printf("So so \n");
				break;
			case F:
				printf("Fail \n");
				break;
			default:
				printf("Please enter number from 1 to 5. \n");
				break;
		}
	}
}
