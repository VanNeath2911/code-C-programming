#include<stdio.h>
enum monthofyear{
	JANUARY=1, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
};
main(){
	enum monthofyear month;
	while(1){
		printf("Enter a number (1 for January, 2 for february...):");
		scanf("%d", &month);
		switch(month){
			case JANUARY:
				printf("January\n");
				break;
			case FEBRUARY:
				printf("Februaday\n");
				break;
			case MARCH:
				printf("March\n");
				break;
			case APRIL:
				printf("April\n");
				break;
			case MAY:
				printf("May\n");
				break;
			case JUNE:
				printf("June\n");
				break;
			case JULY:
				printf("July\n");
				break;
			case AUGUST:
				printf("August\n");
				break;
			case SEPTEMBER:
				printf("September\n");
				break;
			case OCTOBER:
				printf("October\n");
				break;
			case NOVEMBER:
				printf("November\n");
				break;
			case DECEMBER:
				printf("December\n");
				break;
			default:
				printf("Enter number from 1 to 12. Try again!\n");
				break;
				
					
		}	
	}
}
