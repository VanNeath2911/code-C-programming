#include<stdio.h>
enum DayOfWeek{
	MONDAY=1, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
};
main(){
	enum DayOfWeek day;
	while(1){
		printf("Enter a number (1 for Monday, 2 for Tuesday...): ");
		scanf("%d", &day);
		switch(day){
			case MONDAY:
				printf("Monday\n");
				break;
			case TUESDAY:
				printf("Tuesday\n");
				break;
			case WEDNESDAY:
				printf("Wednesday\n");
				break;
			case THURSDAY:
				printf("Thursday\n");
				break;
			case FRIDAY:
				printf("Friday\n");
				break;
			case SATURDAY:
				printf("Saturday\n");
				break;
			case SUNDAY:
				printf("Sunday\n");
				break;
			default:
				printf("Please input number from 1 to 7.\n");
				break;
		}
		
	}
}

