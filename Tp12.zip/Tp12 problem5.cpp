#include<stdio.h>
enum TrafficLight{
   Green=1, Yellow, Red
};
main(){
	enum TrafficLight color;
	while(1){
		printf("Enter a color: ");
		scanf("%d", &color);
    	switch(color){
        	case Green:
            	printf("Color: \033[1;32mGreen\033[0m.\n");
            	break;
        	case Yellow:
           		printf("Color: \033[1;33mYellow\033[0m.\n");
            	break;
        	case Red:
        		printf("Color: \033[1;31mRed\033[0m.\n");
            	break;
        	default:
           		printf("Unknown Color. Please enter number from 1 to 3.\n");
           		break;
    	}
	}
}
