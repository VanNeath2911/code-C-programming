#include <stdio.h>
int main() {
    int num1, num2, num3, num4, num5, num6, num7;
    int min;
	printf("Enter number #1:");scanf("%d",&num1);
	printf("Enter number #2:");scanf("%d",&num2);
	printf("Enter number #3:");scanf("%d",&num3);
	printf("Enter number #4:");scanf("%d",&num4);
	printf("Enter number #5:");scanf("%d",&num5);
	printf("Enter number #6:");scanf("%d",&num6);
	printf("Enter number #7:");scanf("%d",&num7);

    min = num1;
    if (num2 < min){
        min = num2;
    }
    if (num3 < min){
        min = num3;
    }
    if (num4 < min){
        min = num4;
    }
    if (num5 < min){
        min = num5;
    }
    if (num6 < min){
        min = num6;
    }
    if (num7 < min){
        min = num7;
    }
    printf("The minimum number is: %d\n", min);

    return 0;
}
