#include <stdio.h>
int main() {
    char gender;
    char name[50];
    float salary, tax;
    printf("Enter gender: ");scanf(" %c", &gender);
    printf("What is your name?: ");scanf("%s", name);
    printf("Your salary in USD: ");scanf("%f", &salary);
    if (gender == 'M') {
        if (salary > 400) {
            tax = 0.1 * salary;
        } else if (salary >= 200) {
            tax = 0.05 * salary;
        } else {
            tax = 0;
        }
    } else if (gender == 'F') {
        if (salary > 500) {
            tax = 0.05 * salary;
        } else if (salary >= 250) {
            tax = 0.03 * salary;
        } else {
            tax = 0;
        }
    } else {
        printf("Invalid gender input.\n");
        return 1;
    }
    printf("Hi %s, based on your given information,\nthe tax salary that you need to pay: %.2f USD.\n", name, tax);

    return 0;
}

