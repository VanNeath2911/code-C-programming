#include <stdio.h>
int main() {
    int num1, num2, num3, num4, num5, num6, num7, num8, num9, num10;
    int max, min;
    // Input for the 10 numbers
    printf("Enter number #1: ");
    scanf("%d", &num1);
    max = min = num1;

    printf("Enter number #2: ");
    scanf("%d", &num2);
    if (num2 > max) max = num2;
    if (num2 < min) min = num2;

    printf("Enter number #3: ");
    scanf("%d", &num3);
    if (num3 > max) max = num3;
    if (num3 < min) min = num3;

    printf("Enter number #4: ");
    scanf("%d", &num4);
    if (num4 > max) max = num4;
    if (num4 < min) min = num4;

    printf("Enter number #5: ");
    scanf("%d", &num5);
    if (num5 > max) max = num5;
    if (num5 < min) min = num5;

    printf("Enter number #6: ");
    scanf("%d", &num6);
    if (num6 > max) max = num6;
    if (num6 < min) min = num6;

    printf("Enter number #7: ");
    scanf("%d", &num7);
    if (num7 > max) max = num7;
    if (num7 < min) min = num7;

    printf("Enter number #8: ");
    scanf("%d", &num8);
    if (num8 > max) max = num8;
    if (num8 < min) min = num8;

    printf("Enter number #9: ");
    scanf("%d", &num9);
    if (num9 > max) max = num9;
    if (num9 < min) min = num9;

    printf("Enter number #10: ");
    scanf("%d", &num10);
    if (num10 > max) max = num10;
    if (num10 < min) min = num10;

    // Display the results
    printf("Among these 10 numbers (%d, %d, %d, %d, %d, %d, %d, %d, %d, %d), the max is %d and the min is %d.\n", 
           num1, num2, num3, num4, num5, num6, num7, num8, num9, num10, max, min);

    return 0;
}
