#include <stdio.h>
int main() {
    char name[50];
    float math, english, computer, average;
    printf("Enter student's name: ");scanf("%s", name);
    printf("Enter math score: ");scanf("%f", &math);
    printf("Enter English score: ");scanf("%f", &english);
    printf("Enter Computer score: ");scanf("%f", &computer);

    average = (math + english + computer) / 3.0;

    printf("Average score: %.2f\n", average);
    if (average >= 90) {
        printf("%s's grade: A\n", name);
    } else if (average >= 80) {
        printf("%s's grade: B\n", name);
    } else if (average >= 70) {
        printf("%s's grade: C\n", name);
    } else if (average >= 60) {
        printf("%s's grade: D\n", name);
    } else {
        printf("%s's grade: F\n", name);
    }

    return 0;
}

