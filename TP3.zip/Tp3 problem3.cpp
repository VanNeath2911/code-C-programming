#include<stdio.h>
#include<math.h>
int main(){
	int num;
	printf("Enter a number:");scanf("%d",&num);
	if(num<0 && num%2!=0){
		printf("We got nagative and odd numbers.");
	}
	else if(num<0 && num%2==0){
		printf("We got negative ang even numbers.");
	}
	else if(num>0 && num%2!=0){
		printf("We got positive and odd numbers.");
	}
	else if(num>0 && num%2==0){
		printf("We got positive and even numbers.");
	}
	return 0;
}
