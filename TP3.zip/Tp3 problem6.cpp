#include<stdio.h>
#include<math.h>
int main(){
	int a,b,c;
	int dalta;
	int x1,x2;
	printf("Solving quadrator ax2+bx+c=0\n");
	printf("Enter coefficient a: ");scanf("%d",&a);
	printf("Enter coefficient b: ");scanf("%d",&b);
	printf("Enter coefficient c: ");scanf("%d",&c);
	
	dalta=b*b - 4*a*c;
	
	if(dalta==0){
		x1=-b/(2*a);
		x2=-b/(2*a);	
		printf("Equation has double is : x1=x2%d",x1,x2);
	}
	else if(dalta>0){
		x1=(-b+sqrt(dalta))/(2*a);
		x2=(-b-sqrt(dalta))/(2*a);
		printf("Equation has two roofs x1=%d and x2=%d",x1,x2);
	}
}
