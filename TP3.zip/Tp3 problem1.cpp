#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char first_Name[50];
    char last_Name[50];
    
    printf("Enter your first name: ");scanf("%s", first_Name);
    printf("Enter your last name: ");scanf("%s", last_Name);
   
    for(int i=0; first_Name[i]; i++) {
        first_Name[i] = tolower(first_Name[i]);
    }
    for(int i=0; last_Name[i]; i++) {
        last_Name[i] = tolower(last_Name[i]);
    }
    printf("Username: %s_%s\n", first_Name,last_Name);
    
    printf("Number of characters in first name: %d\n",strlen(first_Name));
    printf("Number of characters in last name: %d\n",strlen(last_Name));
    
    printf("First character of last name: %c\n",last_Name[0]);
    printf("Last character of first name: %c\n",first_Name[strlen(first_Name) - 1]);
    
    return 0;
}
