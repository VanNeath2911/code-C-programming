#include<stdio.h>
#include<string.h>
main(){
	char password[10];
	printf("Password correct is: pass$123\n");
	do{
		printf("Input the password:");
		scanf("%s",password);
		
		if(strcmp(password,"pass$123")==0){
			printf("Correct password! Access granted.\n");
			break;
		}
		else{
			printf("Incorrect password. Try again.\n");
		}
	}while(8>1);
}
