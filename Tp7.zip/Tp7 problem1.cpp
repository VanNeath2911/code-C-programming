#include<stdio.h>
main(){
	int number=2;
	do{
		if(number/2 != 0){
			printf("%d ", number);
			number = number+2;
		}
	}
	while(number<=2000);
	return 0;
}
