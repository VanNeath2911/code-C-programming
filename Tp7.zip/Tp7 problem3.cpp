#include<stdio.h>
main(){
	int m, n, sum=0;
	int total;
		printf("Enter a number m: ");
		scanf("%d",&m);
		printf("Enter a number n: ");
		scanf("%d", &n);
		if(m>n){
			printf("Oop! We can not compute the summation. n must be bigger than m.");
		}
		else{
		printf("The sum is:");
		do{
			if(m<n){
				printf("%d+",m);
			}else{
				printf("%d=",m);	
			}
			sum = sum + m;
			m++;
		}
		while(m<=n);
		printf("%d", sum);
	}
	
}
