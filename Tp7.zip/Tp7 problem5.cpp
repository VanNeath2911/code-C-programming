#include<stdio.h>
main(){
	int number;
	int sum = 0;
	float average;
	int count = 0;
	
	do{
		printf("Enter a number: ");
		scanf("%d", &number);
		if(number != 0){
			sum = sum + number;
			count++;
		}	
	}while(number != 0);
		if(count==0){
			printf("Can not calculate average.");
		}
		else{
			average = (float)sum / count;
			printf("The average of input numbers: %.2f", average);
		}
	return 0;
}
