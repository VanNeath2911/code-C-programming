#include<stdio.h>
main(){
	int sum=0;
	int number;
	
	do{
		printf("Enter a number:");
		scanf("%d", &number);
		sum = sum + number;
	}while(number != 0);
	printf("The sum of all input number is: %d", sum);
}
