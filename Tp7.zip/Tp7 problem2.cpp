#include<stdio.h>
#include<math.h>
main(){
	int n=0;
	int power;
	
	do{
		power = pow(2,n);
		printf("\n2^%d = %d", n, power );
		n++;
	}while(n<=10);
}
