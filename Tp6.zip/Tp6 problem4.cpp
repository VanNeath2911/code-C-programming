#include<stdio.h>
main(){
	int i;
	int sum = 0;
	
	while(1<2){
		printf("Enter a number:");scanf("%d",&i);
		
		if(i != 0){
			sum = sum + i;
			i++;
		}else{
			break;
		}
	}
	printf("The sum of all input numbers:%d",sum);
}
