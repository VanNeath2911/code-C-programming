#include<stdio.h>
#include<math.h>
main(){
	int power=1, i=0;
	while(i<=10){
		printf("\n2^%d=%d",i,power);
		i++;
		power=pow(2,i);	
	}
	return 0;
}
