#include<stdio.h>
main(){
    int num = 2;
    printf("All even numbers between [2,2000] are:");
    while(num <= 2000){
        printf("%d ",num);
        num+=2;
    }
return 0;
}
