#include<stdio.h>
#include<stdlib.h>
int main(){
   int number,guess,count=0;
   
   number=rand()%10+1;
   printf("Guess a number between 1 and 10: ");
   while(1){
       scanf("%d",&guess);
       count++;
       if(guess==number){
           printf("Congratulations! You guessed it in %d tries!\n",count);
           break;
       }
	   	else if(guess<number){
           printf("Too low. Guess again: ");
       } 
	   	else{
           printf("Too high. Guess again: ");
       }
   }
   return 0;
}

