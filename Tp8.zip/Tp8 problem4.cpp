#include<stdio.h>
#include<string.h>
main(){
	char names[4][100];
	float scores[4];
	char emails[4][100];
	int ages[4];
	
	for(int i=0; i<4; i++){
		printf("\t*** Getting data for student %d:\n", i+1);
		printf("Name:"); scanf("%s", &names[i]);
		printf("Age:"); scanf("%d", &ages[i]);
		printf("Email:"); scanf("%s", &emails[i]);
		printf("Score:"); scanf("%f", &scores[i]);
	}	
	printf("\tAll data of student in the array are:\n");
	printf("Name	\tAge	\tScore	\tEmail\n");
	for(int i=0; i<4; i++){
		printf("%s	\t%d	\t%.2f	\t%s\n", names[i], ages[i], scores[i], emails[i]);
	}
	return 0;
}








