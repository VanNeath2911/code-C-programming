#include<stdio.h>
main(){
	int numbers[7];
	int sum = 0;
	int total = 0;
	float average;
	int count;
	int max;
	
    for(int i = 0; i < 7; i++) {
        printf("Enter number %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }
    
   	printf("All data in the array are:");
    for(int i = 0; i < 7; i++) {
        printf("%d ", numbers[i]);
        count++;
        sum = sum + numbers[i];
        average = (float)sum/count;
        if(numbers[i]>max){
        	max = numbers[i];
		}
    }
    printf("\nComputed statistical data are: total = %d\n",sum);
    printf("Average is %.2f.\n", average);
    printf("The max number is %d.", max);
    
    return 0;
}
