#include<stdio.h>
#include<string.h>
main(){
 	char names[5][100];
 	int ages[5];
 	float scores[5];
 	char emails[5][100];
 	int count;
 	float average;
 	int sum = 0;
 	
 	printf("\t*** Instruction: Enter name, age, score and email separated by space:\n");
 	
 	for(int i=0; i<5; i++){
 		printf("Input for student %d: ", i+1);
 		scanf("%s %d %f %s", &names[i], &ages[i], &scores[i], &emails[i]);
 		count++;
 		sum = sum + scores[i];
		}
	average = (float)sum/count;
	printf("\tThe average score is: %.2f\n", average);
	printf("\tAll students got score more than the average are:\n");
	printf("Name	\tAge	\tScore	\tEmail\n");
	for(int j=0; j<5; j++){
		if(scores[j]>average){
			printf("%s	\t%d	\t%.2f	\t%s\n", names[j], ages[j], scores[j], emails[j]);
		}
	}
	return 0;	
}
