#include<stdio.h>
main(){
	int numbers[10];
	
    for(int i = 0; i < 10; i++) {
        printf("Enter number %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }
    printf("All data in the array are:");
    for(int j = 0; j < 10; j++) {
    	if(j!=9){
    		printf("%d, ", numbers[j]);
		}else{
			printf("%d. ", numbers[j]);
		}
    }
    return 0;
}
