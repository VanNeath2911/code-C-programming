#include<stdio.h>
int main() {
    int a1[5]={}; 
    int a2[5]={};
    
    printf("\t*** Getting data for the array a1.\n");
    for (int i = 0; i < 5; i++) {
        printf("Enter number %d: ", i + 1);
        scanf("%d", &a1[i]);
    }
    for(int i = 0; i < 5; i++) {
        a2[i] = a1[i];
    }
    printf("All data input by the users are stored successfully in the array a1.\n");
    printf("A new array a2 has been created and it has the same data as a1.\n");
    printf("Display a2 from start to end position:");
    for (int i = 0; i < 5; i++) {
        printf("%d ", a2[i]);
    }
    printf("\nDisplay a2 from end to start position:");
    for (int i = 4; i >= 0; i--) {
        printf("%d ", a2[i]);
    }
    return 0;
}

