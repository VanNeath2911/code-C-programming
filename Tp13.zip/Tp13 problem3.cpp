#include <stdio.h>

struct Account {
    int account_number;
    char name[50];
    float balance;
    char type[20];
};

void display_menu() {
    printf("\nBank Account Management System\n");
    printf("1. Deposit\n");
    printf("2. Withdrawal\n");
    printf("3. Balance Inquiry\n");
    printf("4. Exit\n");
    printf("Enter your choice: ");
}

int main() {
    struct Account account;
    int choice, amount;

    printf("Enter account number: ");
    scanf("%d", &account.account_number);
    printf("Enter account holder name: ");
    scanf("%s", account.name);
    printf("Enter account type (Savings/Current): ");
    scanf("%s", account.type);
    printf("Enter initial balance: ");
    scanf("%f", &account.balance);

    do {
        display_menu();
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter amount to deposit: ");
                scanf("%d", &amount);
                if (amount > 0) {
                    account.balance += amount;
                    printf("Deposit successful! New balance: %.2f\n", account.balance);
                } else {
                    printf("Invalid amount.\n");
                }
                break;
            case 2:
                printf("Enter amount to withdraw: ");
                scanf("%d", &amount);
                if (amount > 0 && amount <= account.balance) {
                    account.balance -= amount;
                    printf("Withdrawal successful! New balance: %.2f\n", account.balance);
                } else {
                    printf("Insufficient funds or invalid amount.\n");
                }
                break;
            case 3:
                printf("Account Balance: %.2f\n", account.balance);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}
