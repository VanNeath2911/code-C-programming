#include <stdio.h>
struct Employee {
    int id;
    char name[50];
    char designation[20];
    float salary;
};
int main() {
    int num_employees, i;
    float total_salary = 0.0;
    printf("Enter the number of employees: ");scanf("%d", &num_employees);
    struct Employee employees[num_employees];
    for (i = 0; i < num_employees; i++) {
        printf("Enter details for employee %d:\n", i + 1);
        printf("ID    : ");scanf("%d", &employees[i].id);
        printf("Name  : ");scanf("%s", employees[i].name);
        printf("Designation: ");scanf("%s", employees[i].designation);
        printf("Salary: ");scanf("%f", &employees[i].salary);

        total_salary += employees[i].salary;
    }
    printf("\nEmployee Details:\n");
    for (i = 0; i < num_employees; i++) {
        printf("ID         : %d\n", employees[i].id);
        printf("Name       : %s\n", employees[i].name);
        printf("Designation: %s\n", employees[i].designation);
        printf("Salary     : %.2f\n", employees[i].salary);
        printf("\n");
    }
    int highest_salary_index = 0;
    for (i = 1; i < num_employees; i++) {
        if (employees[i].salary > employees[highest_salary_index].salary) {
            highest_salary_index = i;
        }
    }
    printf("Employee with Highest Salary:\n");
    printf("ID         : %d\n", employees[highest_salary_index].id);
    printf("Name       : %s\n", employees[i].name);
    printf("Designation: %s\n", employees[i].designation);
    printf("Salary     : %.2f\n", employees[i].salary);
    
    float average_salary = total_salary / num_employees;
    printf("\nAverage Salary: %.2f\n", average_salary);

    return 0;
}
