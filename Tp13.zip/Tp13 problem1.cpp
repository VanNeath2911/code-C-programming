#include<stdio.h>
struct Student{
	char name[30];
	float roll_number;
	int age,grade;
	
};

int main(){
	struct Student student[50];
	int n;
	printf("Enter some student you want : ");scanf("%d",&n);
	for(int i=1;i<=n;i++){
		printf("Enter name        :");scanf("%s",&student[i].name);
		printf("Enter Roll nnumber:");scanf("%f",&student[i].roll_number);
		printf("Enter age         :");scanf("%d",&student[i].age);
		printf("Enter grade       :");scanf("%d",&student[i].grade);
		printf("--------------------------------------------------\n");
	}
	for(int j=1;j<=n;j++){
		printf("Name        : %s \n",student[j].name);
		printf("Roll number : %f \n",student[j].roll_number);
		printf("age         : %d \n",student[j].age);
		printf("grade       : %d \n",student[j].grade);
		
	}	
}
