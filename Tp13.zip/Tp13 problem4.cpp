#include <stdio.h>
#include <string.h>
#define MAX_PRODUCTS 100

struct Product {
    int product_code;
    char name[50];
    int quantity;
    float price;
};

int find_product_index(struct Product products[], int num_products, int product_code) {
    for (int i = 0; i < num_products; i++) {
        if (products[i].product_code == product_code) {
            return i;
        }
    }
    return -1;
}

void display_menu() {
    printf("\nInventory Management System\n");
    printf("1. Add Product\n");
    printf("2. Delete Product\n");
    printf("3. Update Product\n");
    printf("4. Display Inventory\n");
    printf("5. Exit\n");
    printf("Enter your choice: ");
}

int main() {
    struct Product products[MAX_PRODUCTS];
    int num_products = 0, choice, product_code, index;

    do {
        display_menu();
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                if (num_products == MAX_PRODUCTS) {
                    printf("Inventory full!\n");
                } else {
                    printf("Enter product details:\n");
                    printf("Product Code: ");
                    scanf("%d", &products[num_products].product_code);
                    printf("Name: ");
                    scanf("%s", products[num_products].name);
                    printf("Quantity: ");
                    scanf("%d", &products[num_products].quantity);
                    printf("Price: ");
                    scanf("%f", &products[num_products].price);
                    num_products++;
                    printf("Product added successfully!\n");
                }
                break;
            case 2:
                printf("Enter product code to delete: ");
                scanf("%d", &product_code);
                index = find_product_index(products, num_products, product_code);
                if (index == -1) {
                    printf("Product not found!\n");
                } else {
                    // Shift remaining elements to remove deleted product
                    for (int i = index; i < num_products - 1; i++) {
                        products[i] = products[i + 1];
                    }
                    num_products--;
                    printf("Product deleted successfully!\n");
                }
                break;
            case 3:
                printf("Enter product code to update: ");
                scanf("%d", &product_code);
                index = find_product_index(products, num_products, product_code);
                if (index == -1) {
                    printf("Product not found!\n");
                } else {
                    printf("Enter new product details:\n");
                    printf("Name (%s): ", products[index].name);
                    fgets(products[index].name, 50, stdin);
                    products[index].name[strcspn(products[index].name, "\n")] = 0; 
                    printf("Quantity (%d): ", products[index].quantity);
                    scanf("%d", &products[index].quantity);
                    printf("Price (%.2f): ", products[index].price);
                    scanf("%f", &products[index].price);
                    printf("Product updated successfully!\n");
                   
                    getchar();
                }
                break;
            case 4:
                if (num_products == 0) {
                    printf("Inventory is empty!\n");
                } else {
                    printf("\nInventory:\n");
                    printf("Product Code\tName\t\tQuantity\tPrice\n");
                    for (int i = 0; i < num_products; i++) {
                        printf("%d\t\t%s\t\t%d\t\t%.2f\n", products[i].product_code, products[i].name, products[i].quantity, products[i].price);
                    }
                }
                break;
            case 5:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice!\n");
        }
    } while (choice != 5);
}
