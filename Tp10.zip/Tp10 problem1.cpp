#include<stdio.h>
void number(int n){
	for(int i=1;i<=n;i++){
		if(i!=10){
			printf("%d ",i);
		}
	}
}
int main(){
	int n;
	printf("Enter a number: ");scanf("%d" ,&n);
	printf("DIsplay number using function displaySequence(1-%d):\n",n);
	number(n);
	return 0;
}
