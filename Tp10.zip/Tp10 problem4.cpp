#include<stdio.h>
struct MinMax{
	int min,max;
};
struct MinMax findMinMax(int numbers[]){
	struct MinMax c;
	c.max=numbers[0];
	c.min=numbers[0];
	for(int i=0;i<10;i++){
		if(c.max<numbers[i]){
			c.max=numbers[i];
		}
		if(c.min>numbers[i]){
			c.min=numbers[i];
		}
	}
	return c;
};
int main(){
	int num[10];
	for(int i=0;i<10;i++){
		printf("Eneter number #%d: ",i+1);scanf("%d",&num[i]);
	}
	struct MinMax k = findMinMax(num);
	printf("Among the input numbers we foun that: \n");
	for(int j=0;j<10;j++){
		printf("%d ",num[j]);
	}
	printf("The minimum number is : %d",k.min);
	printf("The maximum number is : %d",k.max);
}
