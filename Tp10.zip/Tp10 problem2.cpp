#include <stdio.h>
int computeCube(int n){
    return n*n*n;
}
int main(){
    int num;
    while(1){
        printf("Enter a number: ");scanf("%d",&num);
        if(num<=0){
            printf("Error! Invalid input number! You must input a number greater than 0. Please try again.\n");
            continue;
        }
        int result = computeCube(num);
        printf("The cube of %d equals to: %d\n",num,result);
    }
    return 0;
}
