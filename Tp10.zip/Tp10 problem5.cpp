#include <stdio.h>
#include <math.h>
struct Root {
    int status_code;
    float x1;
    float x2;
};
struct Root solveQuadratic(int a, int b, int c) {
    struct Root root;
    float discriminant = b * b - 4 * a * c;
    if (discriminant > 0) {
        root.status_code = 2;
        root.x1 = (-b + sqrt(discriminant)) / (2 * a);
        root.x2 = (-b - sqrt(discriminant)) / (2 * a);
    }
	else if (discriminant == 0) {
        root.status_code = 1;
        root.x1 = root.x2 = -b / (2 * a);
    }
	else {
        root.status_code = 3;
        root.x1 = -b / (2 * a);
        root.x2 = sqrt(-discriminant) / (2 * a);
    }
    return root;
}

int main() {
    int a, b, c;
    printf("Enter coefficients a, b, and c: ");
    scanf("%d %d %d", &a, &b, &c);
    struct Root result = solveQuadratic(a, b, c);
    if (result.status_code == 1) {
        printf("The equation has a double root: %.2f\n", result.x1);
    } else if (result.status_code == 2) {
        printf("The equation has two real roots: %.2f and %.2f\n", result.x1, result.x2);
    } else {
        printf("The equation has complex roots: %.2f + %.2fi and %.2f - %.2fi\n",
               result.x1, sqrt(-result.x2), result.x1, sqrt(-result.x2));
    }

    return 0;
}
