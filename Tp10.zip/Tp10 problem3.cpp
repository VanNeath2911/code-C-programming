#include <stdio.h>
#include <math.h>
struct Data {
    float diameter;
    float circumference;
    float area;
    float radius;
};
int main(){
    struct Data c;
    printf("Enter radius: ");scanf("%f", &c.radius);
    
    c.diameter = 2*c.radius;
    c.circumference = 2*3.14159265*c.radius;
    c.area = 3.14*pow(c.radius, 2);
    
    printf("The properties of a circle with the given radius %.2f\n",c.radius);
    printf("Diameter      = %.2f\n",c.diameter);
    printf("Circumference = %.2f\n",c.circumference);
    printf("Area          = %.2f\n",c.area);
    
    return 0;
}
