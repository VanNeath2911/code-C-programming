#include<stdio.h>
int isPrime(int num){
    if(num <= 1){
        return 0; 
    }
    for(int i = 2; i*i <= num; i++){
        if(num % i == 0) {
            return 0; 
        }
    }
    return 1; 
}
void displayEvenOdd(int n, int m) {
    printf("Even numbers from %d to %d:\n", n, m);
    for (int i = n; i <= m; i++) {
        if (i % 2 == 0) {
            printf("%d ", i);
        }
    }
    printf("\nOdd numbers from %d to %d:\n", n, m);
    for (int i = n; i <= m; i++) {
        if (i % 2 != 0) {
            printf("%d ", i);
        }
    }
    printf("\n");
}
void displayPrimes(int n, int m) {
    printf("Prime numbers between %d and %d:\n", n, m);
    for (int i = n; i <= m; i++) {
        if (isPrime(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");
}
float computeSuite(int n) {
    float sum = 0;
    for (int i = 1; i <= n; i++) {
        int factorial = 1;
        for (int j = 1; j <= i; j++) {
            factorial *= j;
        }
        sum += 1.0f / (float)factorial; 
    }
    return sum;
}
int main() {
    int choice, n, m, attempts = 0;
    float result;

    while (1) { 
        printf("==================={Menu}===================:\n");
        printf("1. Check if a number is prime\n");
        printf("2. Display even and odd numbers\n");
        printf("3. Display prime numbers\n");
        printf("4. Compute series summation\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("Enter a number: ");
            scanf("%d", &n);
            if (isPrime(n)) {
                printf("%d is a prime number.\n", n);
            } else {
                printf("%d is not a prime number.\n", n);
            }
        } else if (choice == 2) {
            printf("Enter starting and ending numbers for even/odd display: ");
            scanf("%d %d", &n, &m);
            displayEvenOdd(n, m);
        } else if (choice == 3) {
            printf("Enter starting and ending numbers for prime display: ");
            scanf("%d %d", &n, &m);
            displayPrimes(n, m);
        } else if (choice == 4) {
            printf("Enter the number of terms for the series: ");
            scanf("%d", &n);
            result = computeSuite(n);
            printf("The summation of the series is: %.2f\n", result);
        } else if (choice == 5) {
            printf("You have tried the menu %d times. Exiting...\n", attempts);
            return 0;
        } else {
            printf("Invalid choice. Please try again.\n");
        }
    }

    return 0; 
}
