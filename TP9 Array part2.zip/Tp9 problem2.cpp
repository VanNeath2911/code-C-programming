#include<stdio.h>
main(){

    int m1[2][2];
    int m2[2][2];
    int m3[2][2];
    int max , min;
    printf("Enter 4 numbers for matrix m1:\n");
    for(int i=0; i<2; i++){
        for(int j=0; j<2; j++){
            scanf("%d" , &m1[i][j]);
        }
    }
    printf("Enter 4 number for matrix m2:\n");
    for(int i=0; i<2; i++){
        for(int j=0; j<2; j++){
            scanf("%d" , &m2[i][j]);
        }
    }
    printf("\n");
    printf("Sum of matrices (m3):\n");
    for(int i=0; i<2; i++){
        for(int j=0; j<2; j++){
            m3[i][j] = m1[i][j] + m2[i][j];
        }
    }
    max = m3[0][0];
    min = m3[0][0];
    for(int i=0; i<2; i++){
        for(int j=0; j<2; j++){
            printf("%d " , m3[i][j]);
            if(m3[i][j]>max){
                max = m3[i][j];
            }if(m3[i][j]<min){
                min = m3[i][j];
            }
        }
        printf("\n");
    }
    printf("Maximun number in m3:%d\n" , max);
    printf("Minimum number in m3:%d\n" , min);

    return 0;

}
