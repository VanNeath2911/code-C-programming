#include<stdio.h>
main(){
    int size;
    int largest;
    int second_largest;

    printf("Input the size of array:");
    scanf("%d" , &size);

    int Array[size];

    printf("Input %d numbers in the array:\n" , size);
    for(int i=0; i<size; i++){
        printf("Enter number%d:" , i+1);
        scanf("%d" , &Array[i]);
    }

    largest = Array[0];
    second_largest = Array[1];

     if(second_largest > largest) {
        int Arrxy = largest;
        largest = second_largest;
        second_largest = Arrxy;
    }

    for(int j=2; j<size; j++){
        if(Array[j] > largest){
            second_largest = largest;
            largest = Array[j];
        }else if(Array[j] > second_largest && Array[j] != largest){
            second_largest = Array[j];
        }
    }
    printf("The second largest number in the array is : %d" , second_largest);  

    return 0;  
}

