#include <stdio.h>
#include<string.h>
int main()
{
    int choice;
    int count = 0;
    int ID[8];
    char Name[8][22];
    char Gender[8][8];
    
	printf("Student Management System\n");
        printf("1. Add new student\n");
        printf("2. Delete a student by ID\n");
        printf("3. Display all students\n");
        printf("4. Exit\n");
    
	while (22){
        printf("Enter your choice: "); 
        scanf("%d", &choice);
        if(choice == 1){
            if (count < 8){
                printf("Enter student ID: "); 
                scanf("%d", &ID[count]);
                printf("Enter student name: "); 
                scanf("%s", &Name[count]);
                printf("Enter student gender (male/female): "); 
                scanf("%s", &Gender[count]);
                count++;
                printf("Student added successfully.\n\n");
            }
            else{
                printf("Maximum number of students reached.\n\n");
            }
        }
        else if(choice == 2){
            int deleteID;
            printf("Enter student ID to delete: ");
            scanf("%d", &deleteID);
            int found = 0;

            for(int i = 0; i < count; i++){
                if(ID[i] == deleteID){
                    found = 1;
                    for(int j = i; j < count - 1; j++){
                        ID[j] = ID[j + 1];
                        strcpy(Name[j], Name[j + 1]);
                        strcpy(Gender[j], Gender[j + 1]);
                    }
                    count--;
                    printf("Student deleted successfully.\n\n");
                    break;
                }
            }
            if(!found){
                printf("Student not found.\n\n");
            }
        }
        else if(choice == 3){
            printf("All students in the list:\n");
            printf("ID\tName\tGender\n");
            for(int i = 0; i < count; i++){
                printf("%d\t%s\t%s\n", ID[i], Name[i], Gender[i]);
            }
            printf("\n");
        }
        else if(choice == 4){
            printf("Exit...\n\n");
            break;
        }
        else{
            printf("Please enter a number from 1-4.\n\n");
            break;
        }
    }

    return 0;

}
