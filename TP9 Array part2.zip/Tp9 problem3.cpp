#include<stdio.h>
main(){
    int elements[5];
    int n;

    printf("Input 5 elements in the array in ascending order:\n");
    for(int i=0; i<5; i++){
        printf("element-%d:" , i);
        scanf("%d" , &elements[i]);
    }
    printf("Input the position where to delete:");
    scanf("%d" , &n);

    for(int i = n-1; i<4; i++){
        elements[i] = elements[i+1];
    }
    printf("The new list is: ");
    for(int j=0; j<4; j++){
        printf("%d " , elements[j]);
    }

    return 0;
}
