#include<stdio.h>
main(){
	
	int n, sum=0;
	for(n=2; n<50; n=n+2){
		sum = sum + n;
		if(n != 48){
			printf("%d+",n);	
	    }else{
	    	printf("%d",n);
		}
	}
	printf("=%d",sum);
}
