#include<stdio.h>
main(){
	
	int i, num, prime=0;
	printf("Enter a number: ");
	scanf("%d", &num);
	
	for(i=1; i<=num; i++){
		if(num%i==0){
			prime=prime + 1;
		}
	}
	if(prime==2){
		printf("%d is a prime number because it is only divisible by itself and 1.",num);
	}else{
		printf("%d is not a prime number because it is not only divisible by itself and 1.",num);
	}
}
