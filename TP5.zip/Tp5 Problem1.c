#include<stdio.h>
main(){
  int sum=0;
  int sub=0;
  int i;
  
  printf("The summation:");
  for(i=500; i>=10; i--){
  	sum = sum + i;
  	if(i != 10){
  		printf("%d+",i);
	  }else{
	  	printf("%d",i);
	  }
  }
	printf(" =%d\n",sum);
	
	printf("The substraction:");
	for(i=500; i>=10; i=i-1){
		sub = sub - i;
		printf("-%d",i);
	}
	printf("=%d",sub);
return 0;	
}
