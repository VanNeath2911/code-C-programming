#include<stdio.h>
main(){
	int n,i,sum=0;
	printf("Enter a number:");scanf("%d",&n);
	if(n<=1000){
		for(int i=n; i<=1000; i++){
			if(i!=100){
				sum=sum+i;
			}
		}
	}	
	else{
		printf("The number is vavlid:");
	}
	printf("The number is : %d",sum);
}
