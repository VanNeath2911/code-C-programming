#include<stdio.h>
#include<math.h>
main(){
	
	int i;
	int square = 0;
	for(i=1; i<=10; i++){
		square=pow(2,i);
		printf("\n2^%d=%d",i,square);
	}
}
