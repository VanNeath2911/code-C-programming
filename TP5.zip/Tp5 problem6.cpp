#include<stdio.h>
main(){
	
	int n,m,i,j,isPrime;
   printf("Enter n: ");scanf("%d",&n);
   printf("Enter m: ");scanf("%d",&m);
   printf("All prime numbers between %d and %d are: ",n,m);
   for(i=n;i<=m;i++){
       isPrime = 1;
       for(j=2;j*j<=i;j++){
           if(i%j==0){
               isPrime = 0;
               continue;
           }
       }
       if(isPrime){
           printf("%d ", i);
       }
   }
	
}
